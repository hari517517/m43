﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DB_MVC_Entities.Controllers
{
    public class StudentsController : Controller
    {
        Training_23Jan19_PuneEntities1 DB_Context = new Training_23Jan19_PuneEntities1();

        // GET: Students
        public ActionResult Index()
        {
            return View(DB_Context.amgogu_Student_172415.ToList());
        }

        //  Search By Student Name and Student Percentage
        [HttpPost]
        public ActionResult Index(string id1, string id2)
        {
            return View(DB_Context.amgogu_Student_172415.Where(x => x.Student_Name == id1 && x.Student_Percentage==id2).ToList());
        }

        //    Search By Student Code
        //[HttpPost]
        //public ActionResult Index(string id)
        //{
        //    return View(DB_Context.amgogu_Student_172415.Where(x => x.Student_Name == id).ToList());            
        //}

        //[HttpPost]
        //public ActionResult Index(int id)
        //{
        //    return View(DB_Context.amgogu_Student_172415.Where(x => x.Student_Code == id).ToList());
        //}

        public ActionResult Details(int? id)
        {
            amgogu_Student_172415 student= DB_Context.amgogu_Student_172415.Find(id);            
            return View(student);
        }

        public ActionResult Delete(int? id)
        {
            amgogu_Student_172415 student = DB_Context.amgogu_Student_172415.Find(id);           
            return View(student);
        }


        public ActionResult DeleteConfirmed(int? id)
        {
            amgogu_Student_172415 student = DB_Context.amgogu_Student_172415.Find(id);
            DB_Context.amgogu_Student_172415.Remove(student);
            DB_Context.SaveChanges();


            return RedirectToAction("Index", DB_Context.amgogu_Student_172415.ToList());
        }

        public ActionResult Edit(int id)
        {
            amgogu_Student_172415 student = DB_Context.amgogu_Student_172415.Find(id);
            return View(student);
        }

        [HttpPost]
        public ActionResult Edit(amgogu_Student_172415 students)
        {
            //Another Method
            if (ModelState.IsValid)
            {
                amgogu_Student_172415 student = DB_Context.amgogu_Student_172415.Single(s => s.Student_Code == students.Student_Code);
                student.Student_Name = students.Student_Name;
                student.Student_Address = students.Student_Address;
                student.Student_DOB = students.Student_DOB;
                student.Student_Percentage = students.Student_Percentage;
                DB_Context.SaveChanges();

                return RedirectToAction("Index", DB_Context.amgogu_Student_172415.ToList());
            }
            return View(students);
        }

        // New Create
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(amgogu_Student_172415 students)
        {
            if (ModelState.IsValid)
            {
                DB_Context.amgogu_Student_172415.Add(students);
                DB_Context.SaveChanges();
                return RedirectToAction("Index", DB_Context.amgogu_Student_172415.ToList());
            }
            return View();
                                             
        }

        public ActionResult Search()
        {
            var SearchResult = from amgogu_Student_172415 sm in DB_Context.amgogu_Student_172415 as IQueryable<amgogu_Student_172415>
                               where sm.Student_Code == 172415
                               select sm;           
            return View(SearchResult);
        }
        public ActionResult SearchName()
        {
            var SearchResult = from amgogu_Student_172415 sm in DB_Context.amgogu_Student_172415 as IQueryable<amgogu_Student_172415>
                               where sm.Student_Name == "Rani Pushpa"
                               select sm;            
            return View(SearchResult);
        }
        public ActionResult SearchByNameAddress()
        {            
            var SearchResult = from amgogu_Student_172415 sm in DB_Context.amgogu_Student_172415 as IQueryable<amgogu_Student_172415>
                               where sm.Student_Code >= 172000 && sm.Student_Code <= 172999
                               select sm;            
            return View(SearchResult);
        }
        public ActionResult DeleteByNameAddress()
        {
            var SearchResult = from amgogu_Student_172415 sm in DB_Context.amgogu_Student_172415 as IQueryable<amgogu_Student_172415>
                               where sm.Student_Name == "Rani Pushpa" && sm.Student_Address == "Kadapa Nagar"
                               select sm;
            DB_Context.amgogu_Student_172415.RemoveRange(SearchResult);
            DB_Context.SaveChanges();          
            return RedirectToAction("Index", DB_Context.amgogu_Student_172415.ToList());
        }
    };
}